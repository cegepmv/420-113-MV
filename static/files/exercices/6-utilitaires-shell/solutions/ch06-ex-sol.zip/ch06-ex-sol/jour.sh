#!/bin/bash

echo "SVP entrez un nombre"
read n

if [[ $n -eq 0 ]]; then	
	echo "dimanche"
elif [[ $n -eq 1 ]]; then
	echo "lundi"
elif [[ $n -eq 2 ]]; then
	echo "mardi"
elif [[ $n -eq 3 ]]; then
	echo "mercredi"
elif [[ $n -eq 4 ]]; then
	echo "jeudi"
elif [[ $n -eq 5 ]]; then
	echo "vendredi"
elif [[ $n -eq 6 ]]; then
	echo "samedi"
else
	echo "valeur non reconnue"
fi



