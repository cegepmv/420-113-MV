#!/bin/bash

echo "Souhaitez-vous voir:"
echo "  (1) L'espace libre sur le disque"
echo "  (2) L'espace occupé sur le disque"
echo "  (3) L'espace occupé par le répertoire courant"
read rep

if [[ $rep -eq 1 ]]; then
	df -h --output=source,avail |grep "/dev/sd"
elif [[ $rep -eq 2 ]]; then
	du -hs / 2>/dev/null
elif [[ $rep -eq 3 ]]; then
	du -hs . 2>/dev/null
else
	echo "Option non reconnue"
fi
